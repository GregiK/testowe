import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Standalone output = samodzielny server.js gotowy pod cPanel "Setup Node.js App"
  // (Passenger) na Aderlo Cloud - patrz docs/implementation-plan.md, sekcja Deployment.
  output: "standalone",
};

export default nextConfig;
